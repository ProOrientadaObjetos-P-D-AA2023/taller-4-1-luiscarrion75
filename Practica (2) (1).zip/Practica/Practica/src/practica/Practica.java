/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package practica;
import clases.Paquete;
import conexiones.DATpaquetes;
import java.sql.SQLException;
import java.util.Scanner;
import logica.logPaquete;
import java.sql.ResultSet;

public class Practica {
    static logPaquete objlogi = new logPaquete();
    static Practica prac = new Practica();
    static DATpaquetes objdatpaquete = new DATpaquetes();
    static boolean running = true;
    static boolean actualizacionPresentada = false;

    public static void main(String[] args) throws SQLException, ClassNotFoundException {
        Scanner entrada = new Scanner(System.in);
        int op= 0;
        String aux;
        do{
            System.out.println(" <1> Listar paquetes");
            System.out.println(" <2> actualizar estado");
            System.out.println("Salir <6>");
            aux = entrada.nextLine();
            op= Integer.parseInt(aux);
            switch (op){
                case 1:
                    prac.presentar();
                    
                    break;
                case 2:
                    prac.actualizar();
                    break;
                default:
                    throw new AssertionError();
            }
        }while (op!=6);
    }

    public void presentar() throws ClassNotFoundException, SQLException{
        objlogi.listarpaquetes();
    }

    public void actualizar() throws SQLException, ClassNotFoundException {
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese posición para nuevo estado");
        int pos = sc.nextInt(); // Lee la posición desde la entrada del usuario
        ResultSet paquetes = objdatpaquete.RecuperarPaquete();
        // Mover el cursor al registro en la posición especificada
        if (paquetes.absolute(pos)) {
            // Crear un objeto Paquete con los datos del registro actual
            Paquete paquete = new Paquete();
            paquete.setIdPaq(paquetes.getInt("idpaquete"));
            objdatpaquete.insertarEstados(paquete);

            if (!actualizacionPresentada) {
                // Iniciar hilo para mostrar cambios solo si la actualización no se ha presentado antes
                Thread hiloCambio = new Thread(() -> {
                    try {
                        System.out.println("Se ha actualizado el estado del paquete.");
                        actualizacionPresentada = true; // Marcar la actualización como presentada
                        Thread.sleep(2000); // Esperar 2 segundos antes de mostrar el próximo cambio
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                });
                hiloCambio.start(); // Iniciar el hilo para mostrar cambios
            }
        } else {
            System.out.println("No se encontró ningún paquete en la posición especificada.");
        }
    }
}

