/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

/**
 *
 * @author Usuario iTC
 */
class Estado {
 int idEst;
 int  valor;

    public Estado(int idEst, int valor) {
        this.idEst = idEst;
        this.valor = valor; //1 creado 2 despachado 3 entregado
  }

    public int getIdEst() {
        return idEst;
    }

    public void setIdEst(int idEst) {
        this.idEst = idEst;
    }

    public int getValor() {
        return valor;
    }

    public void setValor(int valor) {
        this.valor = valor;
    }

    @Override
    public String toString() {
        return "Estado{" + "idEst=" + idEst + ", valor=" + valor + '}';
    }
   
}

