/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

import java.util.ArrayList;

/**
 *
 * @author Usuario iTC
 */

public class Paquete {
    int idPaq;
    String codigo;
    String observacion;
    ArrayList<Estado> estados = new ArrayList<>();

    public Paquete(int idPaq, String codigo, String observacion) {
        this.idPaq = idPaq;
        this.codigo = codigo;
        this.observacion = observacion;
        this.estados.add(new Estado(1, 1));
        this.estados.add(new Estado(2, 0));
        this.estados.add(new Estado(3, 0));
    }

    public Paquete() {
        this.estados.add(new Estado(1, 1));
        this.estados.add(new Estado(2, 0));
        this.estados.add(new Estado(3, 0));
    }

    public int getIdPaq() {
        return idPaq;
    }

    public void setIdPaq(int idPaq) {
        this.idPaq = idPaq;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getObservacion() {
        return observacion;
    }

    public void setObservacion(String observacion) {
        this.observacion = observacion;
    }

    public ArrayList<Estado> getEstados() {
        return estados;
    }

    public void setEstados(ArrayList<Estado> estados) {
        this.estados = estados;
    }

    public void actualizarPaquete(int pos) {
        if (pos >= 0 && pos < estados.size()) {
            this.estados.get(pos).valor = pos + 1;
        } else {
            System.out.println("Posición no válida"); // Manejo de posición no válida
        }
    }

    @Override
    public String toString() {
        return "Paquete{" + "idPaq=" + idPaq + ", codigo=" + codigo + ", observacion=" + observacion + ", estados=" + estados + '}';
    }
}

