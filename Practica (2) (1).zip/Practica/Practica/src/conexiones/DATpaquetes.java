/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conexiones;

import clases.Paquete;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


/**
 *
 * @author djaramillo
 */
public class DATpaquetes {
    Conexiones BLcon = new Conexiones();
    
   public ResultSet RecuperarPaquete() throws ClassNotFoundException, SQLException {
    String Sentencia = "SELECT * FROM paquete"; // Corregir la consulta SQL
    PreparedStatement ps = BLcon.getConnection().prepareStatement(Sentencia, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
    return ps.executeQuery();
}
    public int insertarEstados(Paquete  objpac) throws SQLException, ClassNotFoundException {
        String Sentencia = "Insert into estado (idpaquete,VALOR) "
                + "values (?,?)";
        PreparedStatement ps = BLcon.getConnection().prepareStatement(Sentencia);
        ps.setInt(1,objpac.getIdPaq());
        ps.setInt(2, 0);
        
        //ps.setString(3, objCliente.getApellido());
        return ps.executeUpdate(); //1 si se inserta -- 0 si no inserta
 
   }
    }

