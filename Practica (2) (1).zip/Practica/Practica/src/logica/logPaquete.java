/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package logica;

import clases.Paquete;
import conexiones.DATpaquetes;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Usuario iTC
 */
public class logPaquete {
    DATpaquetes objpaquetel = new DATpaquetes();
  Paquete objpac = new Paquete();
  List<Paquete> paquet = new ArrayList<>();
   
   public void listarpaquetes() throws ClassNotFoundException, SQLException {
    
    DATpaquetes objpaquetel = new DATpaquetes(); 
    ResultSet rs = objpaquetel.RecuperarPaquete();
    
    while (rs.next()) {
        int idPaq = rs.getInt("idpaquete"); 
        String codigo = rs.getString("codigo"); 
        String observacion = rs.getString("observacion");
        Paquete paquete = new Paquete(idPaq, codigo, observacion);
        System.out.println(paquete.toString()); 
    }
    
    rs.close(); 
}
   
public void agregarEstados(Paquete paquete) throws SQLException, ClassNotFoundException{
        objpaquetel.insertarEstados(paquete);
    }  

}
